module.exports = {
    JWT_SECRET: "IPEC_Private_Key",
};
